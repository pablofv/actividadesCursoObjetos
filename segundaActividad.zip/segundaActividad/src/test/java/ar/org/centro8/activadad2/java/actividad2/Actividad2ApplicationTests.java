package ar.org.centro8.activadad2.java.actividad2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
