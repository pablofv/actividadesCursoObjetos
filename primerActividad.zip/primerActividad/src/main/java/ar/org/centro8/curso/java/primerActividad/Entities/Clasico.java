package ar.org.centro8.curso.java.primerActividad.Entities;

public class Clasico extends Vehiculo {

    public Clasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }   
}
