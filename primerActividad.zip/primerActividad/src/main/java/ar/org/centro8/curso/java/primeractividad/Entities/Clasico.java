package ar.org.centro8.curso.java.primeractividad.Entities;

public class Clasico extends Vehiculo {

    public Clasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }   
}
