package ar.org.centro8.curso.java.primerActividad.primerActividad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ar.org.centro8.curso.java.primeractividad.Entities.Clasico;
import ar.org.centro8.curso.java.primeractividad.Entities.Nuevo;

@SpringBootTest
class PrimerActividadApplicationTests {

    

}
