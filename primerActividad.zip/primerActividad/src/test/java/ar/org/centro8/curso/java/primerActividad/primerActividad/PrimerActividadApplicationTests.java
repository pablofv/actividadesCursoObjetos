package ar.org.centro8.curso.java.primerActividad.primerActividad;

import ar.org.centro8.curso.java.primerActividad.Entities.Clasico;
import ar.org.centro8.curso.java.primerActividad.Entities.Nuevo;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerActividadApplicationTests {

    

}
