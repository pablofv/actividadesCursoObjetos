package ar.org.centro8.curso.java.proyecto.enums;

public enum Unidad {
    KG,
    LT,
    UNIDAD
}
