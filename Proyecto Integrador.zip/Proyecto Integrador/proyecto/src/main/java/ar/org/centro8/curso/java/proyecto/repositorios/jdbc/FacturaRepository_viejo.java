package ar.org.centro8.curso.java.proyecto.repositorios.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyecto.entities.Factura_viejo;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_FacturaRepository_viejo;

public class FacturaRepository_viejo implements I_FacturaRepository_viejo {
    private Connection conn;
    
    public FacturaRepository_viejo(Connection conn) {
        this.conn = conn;
    }
    @Override
    public void save(Factura_viejo factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void remove(Factura_viejo factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void update(Factura_viejo factura) {
        // TODO Auto-generated method stub
        
    }

    // @Override
    // public List<Factura> getAll() {
    //     List<Factura> list = new ArrayList<>();
    //     try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
    //         while(rs.next()){
    //             list.add(new Factura(
    //                                 rs.getInt("id"),
    //                                 rs.getDate("fechaFactura"),
    //                                 rs.getDouble("totalFacturado"),
    //                                 rs.getInt("idColegio")
    //                     )
    //             );
    //         }
            
    //     } catch (Exception e) {
    //         System.out.println(e);
    //     }
    //     return list;
    // }
    @Override
    public List<Factura_viejo> getAll() {
        List<Factura_viejo> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
            while(rs.next()){
                list.add(new Factura_viejo(
                                    rs.getInt("id"),
                                    rs.getDate("fechaFactura"),
                                    rs.getDouble("totalFacturado"),
                                    rs.getInt("idColegio")
                        )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
 
}
