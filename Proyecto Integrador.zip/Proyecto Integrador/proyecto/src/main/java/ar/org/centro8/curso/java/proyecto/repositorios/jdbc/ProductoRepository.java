package ar.org.centro8.curso.java.proyecto.repositorios.jdbc;

public class ProductoRepository {
    
}
