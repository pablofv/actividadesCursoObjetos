package ar.org.centro8.curso.java.proyecto.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import ar.org.centro8.curso.java.proyecto.connections.Connector;
import ar.org.centro8.curso.java.proyecto.entities.Colegio;
import ar.org.centro8.curso.java.proyecto.entities.Factura;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_ColegioRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_FacturaRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.jdbc.ColegioRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.jdbc.FacturaRepository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn= Connector.getConnection();
        // I_ColegioRepository cr = new ColegioRepository(conn);
        I_FacturaRepository fr = new FacturaRepository(conn);
        //  Colegio colegio = new Colegio("JI Nº902 Alfonsina Storni", "Capdevilla 5905, Villa Ballester, Provincia Bs.As.");
        // // cr.save(colegio);
    
        // colegio = cr.getById(4);
        // colegio.setNombre("Jardín de infantes nº902");
        // //cr.update(colegio);

        // // Mostrar todos
        // System.out.println("\nTodos\n");
        // cr.getAll().forEach(System.out::println);

        // //Buscar por dirección
        // System.out.println("\nBuscando por dirección:\n");
        // cr.getLikeDireccion("Simon").forEach(System.out::println);
        // cr.getLikeDireccion("Alsina").forEach(System.out::println);
        // cr.getLikeDireccion("Rawson").forEach(System.out::println);

        // //Buscar por nombre
        // System.out.println("\nBuscando por nombre:\n");
        // cr.getLikeNombre("68").forEach(System.out::println);
        // cr.getLikeNombre("47").forEach(System.out::println);
        // cr.getLikeNombre("502").forEach(System.out::println);

        // //Borramos un colegio
        // cr.remove(cr.getById(5));
        //cr.remove(cr.getLikeDireccion("908"));
        System.out.println("For each de la colección: ");
        fr.getAll().forEach(System.out::println);
        
        try {
            Date fecha = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse("27/10/2017 00:03");
            Factura factura = new Factura(fecha, 2);
            // System.out.println("La factura creada es: " + factura);
            fr.save(factura);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        // System.out.println("La factura 2:" + fr.getById(2));
        // System.out.println("La fecha de la factura 2:" + fr.getById(2).getFechaFactura());
        

        // Calendar calendar = Calendar.getInstance(); // Obtiene una instancia de Calendar
        // calendar.setTime(fr.getById(2).getFechaFactura()); // Asigna la fecha al Calendar
        // System.out.println(calendar.getTime());
        // Date dt = new Date();
        // System.out.println("Fecha y hora: "+ new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(dt));

     
        // List<Factura> list = new ArrayList<Factura>();
        // SimpleDateFormat sdfDias = new SimpleDateFormat("yyyy-MM-dd");
        // SimpleDateFormat sdfHoras = new SimpleDateFormat("HH:mm:ss");
        // Date fechaConHora;
        // String stringFechaConHora;
        // try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
        //     while(rs.next()){
        //         // System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("fechaFactura")));
        //         // System.out.println(new SimpleDateFormat("hh:mm:ss").format(rs.getTime("fechaFactura")));
        //         stringFechaConHora = sdfDias.format(rs.getDate("fechaFactura")) + " " + sdfHoras.format(rs.getTime("fechaFactura"));
        //         System.out.println("El String fecha: " + stringFechaConHora);
        //         fechaConHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(stringFechaConHora);
        //         System.out.println("La variable Date es: " + fechaConHora.toString());
        //         list.add(new Factura(
        //                             rs.getInt("id"),
        //                             fechaConHora,
        //                             rs.getDouble("totalFacturado"),
        //                             rs.getInt("idColegio")
        //                 )
        //         );
        //     }
            
        // } catch (Exception e) {
        //     System.out.println(e);
        // };

        // for(Factura l:list){
        //     System.out.println("Fecha y hora: "+ new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(l.getFechaFactura()));
        // }
    }
}
