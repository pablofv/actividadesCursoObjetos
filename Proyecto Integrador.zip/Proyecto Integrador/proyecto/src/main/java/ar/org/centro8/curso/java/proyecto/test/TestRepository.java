package ar.org.centro8.curso.java.proyecto.test;

import java.sql.Connection;

import ar.org.centro8.curso.java.proyecto.connections.Connector;
import ar.org.centro8.curso.java.proyecto.entities.Colegio;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_ColegioRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_FacturaRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.jdbc.ColegioRepository;
import ar.org.centro8.curso.java.proyecto.repositorios.jdbc.FacturaRepository;
import java.util.Calendar;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn= Connector.getConnection();
        I_ColegioRepository cr = new ColegioRepository(conn);
        I_FacturaRepository fr = new FacturaRepository(conn);
        //  Colegio colegio = new Colegio("JI Nº902 Alfonsina Storni", "Capdevilla 5905, Villa Ballester, Provincia Bs.As.");
        // // cr.save(colegio);

        // colegio = cr.getById(4);
        // colegio.setNombre("Jardín de infantes nº902");
        // //cr.update(colegio);

        // // Mostrar todos
        // System.out.println("\nTodos\n");
        // cr.getAll().forEach(System.out::println);

        // //Buscar por dirección
        // System.out.println("\nBuscando por dirección:\n");
        // cr.getLikeDireccion("Simon").forEach(System.out::println);
        // cr.getLikeDireccion("Alsina").forEach(System.out::println);
        // cr.getLikeDireccion("Rawson").forEach(System.out::println);

        // //Buscar por nombre
        // System.out.println("\nBuscando por nombre:\n");
        // cr.getLikeNombre("68").forEach(System.out::println);
        // cr.getLikeNombre("47").forEach(System.out::println);
        // cr.getLikeNombre("502").forEach(System.out::println);

        // //Borramos un colegio
        // cr.remove(cr.getById(5));
        //cr.remove(cr.getLikeDireccion("908"));

        System.out.println("La factura 2:" + fr.getById(2));
        System.out.println("La fecha de la factura 2:" + fr.getById(2).getFechaFactura());
        

        Calendar calendar = Calendar.getInstance(); // Obtiene una instancia de Calendar
        calendar.setTime(fr.getById(2).getFechaFactura()); // Asigna la fecha al Calendar
        System.out.println(calendar.getTime());
    }
}
