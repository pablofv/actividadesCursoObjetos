package ar.org.centro8.curso.java.proyecto.repositorios.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyecto.entities.Factura;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_FacturaRepository;

public class FacturaRepository implements I_FacturaRepository {
    private Connection conn;
    
    public FacturaRepository(Connection conn) {
        this.conn = conn;
    }
    @Override
    public void save(Factura factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void remove(Factura factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void update(Factura factura) {
        // TODO Auto-generated method stub
        
    }

    // @Override
    // public List<Factura> getAll() {
    //     List<Factura> list = new ArrayList<>();
    //     try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
    //         while(rs.next()){
    //             list.add(new Factura(
    //                                 rs.getInt("id"),
    //                                 rs.getDate("fechaFactura"),
    //                                 rs.getDouble("totalFacturado"),
    //                                 rs.getInt("idColegio")
    //                     )
    //             );
    //         }
            
    //     } catch (Exception e) {
    //         System.out.println(e);
    //     }
    //     return list;
    // }
    @Override
    public List<Factura> getAll() {
        List<Factura> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
            while(rs.next()){
                list.add(new Factura(
                                    rs.getInt("id"),
                                    rs.getDate("fechaFactura"),
                                    rs.getDouble("totalFacturado"),
                                    rs.getInt("idColegio")
                        )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
 
}
