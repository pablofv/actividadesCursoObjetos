package ar.org.centro8.curso.java.proyecto.test;

import java.util.Calendar;
import java.util.Date;

import ch.qos.logback.core.net.SyslogOutputStream;

public class TestDate {
    public static void main(String[] args) {
        Date d = new Date(122, 5, 15, 21, 16, 11);
        //Calendar calendar = Calendar.getInstance(); // Obtiene una instancia de Calendar
        //calendar.setTime(d); // Asigna la fecha al Calendar
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(d);

        System.out.println("getDate: " + (1900 + d.getYear())  + "/" + d.getMonth()   + "/" + d.getDate());
        System.out.println("getTime: " +         d.getHours()  + ":" + d.getMinutes() + ":" + d.getSeconds());
        System.out.println(calendar.getTime());
    }
    
}
