package ar.org.centro8.curso.java.proyecto.repositorios.interfaces;

public class I_FacturaRepository {
    
}
