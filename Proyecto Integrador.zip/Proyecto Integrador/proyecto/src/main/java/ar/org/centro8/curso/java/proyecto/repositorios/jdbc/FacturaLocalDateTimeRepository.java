package ar.org.centro8.curso.java.proyecto.repositorios.jdbc;

import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ArrayList;

import ar.org.centro8.curso.java.proyecto.entities.Factura;
import ar.org.centro8.curso.java.proyecto.entities.FacturaLocalDateTime;
import ar.org.centro8.curso.java.proyecto.repositorios.interfaces.I_FacturaLocalDateTimeRepository;

public class FacturaLocalDateTimeRepository implements I_FacturaLocalDateTimeRepository{
    private Connection conn;
    
    public FacturaLocalDateTimeRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<FacturaLocalDateTime> getAll() {
        List<FacturaLocalDateTime> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from facturas")){
            while(rs.next()){
                LocalDateTime ldt=LocalDateTime.of(arg0, arg1, arg2, arg3, arg4, arg5);
                list.add(new FacturaLocalDateTime(
                                    rs.getInt("id"),
                                    rs.getDate("fechaFactura").getDay(),
                                    rs.getDate("fechaFactura").getMonth(),
                                    rs.getDouble("totalFacturado"),
                                    rs.getInt("idColegio")
                        )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Factura factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void remove(Factura factura) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void update(Factura factura) {
        // TODO Auto-generated method stub
        
    }
}

