package ar.org.centro8.curso.java.proyecto.repositorios.interfaces;

import java.util.Date;
import java.util.List;

import ar.org.centro8.curso.java.proyecto.entities.Factura_viejo;

public interface I_FacturaRepository_viejo {
    void save(Factura_viejo factura);
    void remove(Factura_viejo factura);
    void update(Factura_viejo factura);

    List<Factura_viejo>getAll();

    default Factura_viejo getById(int id){
        return getAll()
                .stream()
                .filter(f->f.getId() == id)
                .findFirst()
                .orElse(new Factura_viejo());
    }

    default List<Factura_viejo> getByIdColegio(int id){
        return getAll()
                    .stream()
                    .filter(f->f.getIdColegio() == id)
                    .toList();
    }

    default List<Factura_viejo> getByFecha(Date fecha){
        return getAll()
                    .stream()
                    .filter(f -> f.getFechaFactura() != null && f.getFechaFactura() == fecha)
                    .toList();
    }
}
