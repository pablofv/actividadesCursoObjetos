insert into colegios(nombre, direccion) values ('EEI Nº68 Gabriela Mistral', "Profesor Simon 1463, Villa Ballester, Provincia Bs.As."); -- EEI escuela de educación inicial
insert into colegios(nombre, direccion) values ('EEI Nº47 Huestes Salteñas', "Quintana 5895, Villa Ballester, Provincia Bs.As.");
insert into colegios(nombre, direccion) values ('EEI Nº9 Dr. Pedro Ballester', "Bv. Ballester 5428, Villa Ballester, Provincia Bs.As.");
insert into colegios(nombre, direccion) values ('EES Nº44 Almafuerte", "Rio Negro 2561, José León Suarez, Provincia Bs.As."); -- EES escuela de educación secundaria
insert into colegios(nombre, direccion) values ('EES Nº8 Esteban Echeverría", "Rawson 1918, José León Suarez, Provincia Bs.As.");
insert into colegios(nombre, direccion) values ('JI Nº908 Merceditas de San Martín", "Ayacucho 3129, San Andrés, Provincia Bs.As."); -- JI jardín de infantes

INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values ('Leche descremada', 'La Serenísima', 'LACTEOS', 90, 'LT', 12);
INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values ('Manzana', 'S/M', 'FRUTAS', 15, 'UNIDAD', 1);
INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values (nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad);
INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values (nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad);
INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values (nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad);
INSERT INTO distribuidora.productos(nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad)
							values (nombre, marca, tipoProducto, precioCosto, unidad, cantidadPorUnidad);