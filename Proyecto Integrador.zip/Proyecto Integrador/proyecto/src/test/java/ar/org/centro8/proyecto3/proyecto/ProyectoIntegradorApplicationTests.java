package ar.org.centro8.proyecto3.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
